module Practica1 where

--1 Función: middle
-- Recibe una 5-tupla y regresa el 3er elemento.
middle :: (Int,Int,Int,Int,Int) -> Int
middle (a,b,c,d,e) =(c)


add :: (Int, Int, Int, Int) -> Int
add (a,b,c,d) = (a+b+c+d)


greater :: (Int, Int, Int) -> Int
greater (a,b,c) = if(a > b && a>c) then a else if(b > a && b>c) then b else c


less :: (Int, Int, Int) -> Int
less (a,b,c) = if(a < b && a<c) then a else if(b < a && b<c) then b else c


isPair :: (Int, Int, Int, Int) -> Bool
isPair (a,b,c,d) = if (mod a 2==0) && (mod b 2==0) && (mod c 2==0) && (mod d 2==0) then True else False


swip :: (a, a) -> (a, a)
swip = error "Implementar."


sort :: (a,a,a,a) -> (a,a,a,a)
sort = error "Implementar."
